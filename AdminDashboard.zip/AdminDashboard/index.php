<?php
session_start();
include "includes/header.php";
require_once 'model/User.php'; 
$user = new User();

// Get users
$users = $user->getAllUsers();

// Assuming the logged-in user's role is stored in the session
$logged_in_role = $_SESSION['user_role']; // Adjust this based on how you're handling login
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Your head content here -->
</head>
<body>
    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800" style="color:#858796;">Users Dashboard</h1>

        <!-- Add User Button: Only visible for superAdmin -->
        <?php if ($logged_in_role === 'superAdmin'): ?>
            <div class="row mb-3">
                <div>
                    <button type="button" class="addbutton" onclick="openAddModal()">
                        <span class="button__text">Add New User</span>
                        <span class="button__icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" viewBox="0 0 24 24" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor" height="24" fill="none" class="svg">
                                <line y2="19" y1="5" x2="12" x1="12"></line>
                                <line y2="12" y1="12" x2="19" x1="5"></line>
                            </svg>
                        </span>
                    </button>
                </div>
            </div>
        <?php endif; ?>

        <div class="pt-5 pb-3 table_pro_item">
            <h2>Users Table</h2>
            <table class="responsive-table table_pro_item " id="myTable">
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Birth Date</th>
                        <th>Phone Number</th>
                        <th>Address</th>
                        <th>State</th>
                        <!-- Only show Role column if the logged-in user is superAdmin -->
                        <?php if ($logged_in_role === 'superAdmin'): ?>
                            <th>Role</th>
                        <?php endif; ?>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td data-label="User ID"><?php echo htmlspecialchars($u['user_id']); ?></td>
                        <td data-label="First Name"><?php echo htmlspecialchars($u['user_first_name']); ?></td>
                        <td data-label="Last Name"><?php echo htmlspecialchars($u['user_last_name']); ?></td>
                        <td data-label="Email"><?php echo htmlspecialchars($u['user_email']); ?></td>
                        <td data-label="Gender"><?php echo htmlspecialchars($u['user_gender']); ?></td>
                        <td data-label="Birth Date"><?php echo htmlspecialchars($u['user_birth_date']); ?></td>
                        <td data-label="Phone Number"><?php echo htmlspecialchars($u['user_phone_number']); ?></td>
                        <td data-label="Address"><?php echo htmlspecialchars($u['user_address']); ?></td>
                        <td data-label="State"><?php echo htmlspecialchars($u['user_status']); ?></td>
                        <!-- Only show Role data if the logged-in user is superAdmin -->
                        <?php if ($logged_in_role === 'superAdmin'): ?>
                            <td data-label="Role"><?php echo htmlspecialchars($u['user_role']); ?></td>
                        <?php endif; ?>
                        <td data-label="Actions">
                            <div class="action-buttons">
                                <button class="edit-btn" onclick="openEditModal(this, <?php echo $u['user_id']; ?>)">
                                    <i class="bi bi-pencil-square"></i>
                                </button>
                                <form method="POST" action="process_user.php" style="display: inline;">
                                    <input type="hidden" name="deleteUserId" value="<?php echo $u['user_id']; ?>">
                                    <button class="delete-btn" type="button" onclick="confirmDelete(this)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- The rest of your code for modals and scripts -->

</body>
</html>
