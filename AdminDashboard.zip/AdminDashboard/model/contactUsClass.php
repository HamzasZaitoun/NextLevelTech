<?php
require_once 'Database.php';


class messages
{
    
}

?>